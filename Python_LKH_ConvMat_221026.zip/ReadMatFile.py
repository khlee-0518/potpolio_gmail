from ctypes import BigEndianStructure
import math     #   log, ceil, floor
import pickle   #   Store Dict
import random   #   random number gen
import numpy as np
from socket import socket
from scipy import io

aDic = io.loadmat('CSAR_LUT.mat')

#scores = {"a": [2, 3, 90], "b": [4, 5, 85], "c": [5, 7,80]}
#print(scores['a'])
#print(list(scores.keys()))

NumLUT = 32
LastLUT = NumLUT-1
BlockSize = 128

def GetQstFromDic(Bit):
    sName = 'CSAR_QST_%d' % Bit
    return aDic[sName]

def GetLutFromDic(Bit):
    sName = 'CSAR_LUT_%d' % Bit
    return aDic[sName]

def PrintTest():
    print(GetLutFromDic(4))

def CeilLog10(x):
    return math.ceil(math.log10(x))

def CeilLog16(x):
    return math.ceil(math.log2(x)/4)

def PrintMat4Chirp():
    aChirp = io.loadmat('input_chirp_deci.mat')
    print(aChirp)
    aComp = aChirp['input_chirp_deci']
    DataFileReal = open('DataOutReal.txt', 'w')
    DataFileImage = open('DataOutImage.txt', 'w')
    for list in aComp:
        for Complex in list:
            DataFileReal.write('%f\n' % Complex.real);  # numpy.complex128
            DataFileImage.write('%f\n' % Complex.imag);
    DataFileReal.close()
    DataFileImage.close()

def PrintMat4Chirp1g():
    aChirp = io.loadmat('1g_cw_hex.mat')
    print(aChirp)
    aComp = aChirp['chirp_data_hex']
    DataFileReal = open('DataOutReal1g.txt', 'w')
    for data in aComp:
        if(int(data,16) > 32767):
            DataFileReal.write('%d\n' % -(65536 - int(data,16)) );  
        else:
            DataFileReal.write('%d\n' % int(data,16));  
    DataFileReal.close()

def PrintMat4Chirp1g5():
    aChirp = io.loadmat('1g5_cw_hex.mat')
    print(aChirp)
    aComp = aChirp['chirp_data_hex']
    DataFileReal = open('DataOutReal1g5.txt', 'w')
    for data in aComp:
        if(int(data,16) > 32767):
            DataFileReal.write('%d\n' % -(65536 - int(data,16)) );  
        else:
            DataFileReal.write('%d\n' % int(data,16));  
    DataFileReal.close()

def PrintMat4ChirpHex():
    aChirp = io.loadmat('chirp_data_hex.mat')
    print(aChirp)
    aComp = aChirp['chirp_data_hex']
    DataFileReal = open('DataOutRealHex.txt', 'w')
    for data in aComp:
        if(int(data,16) > 32767):
            DataFileReal.write('%d\n' % -(65536 - int(data,16)) );  
        else:
            DataFileReal.write('%d\n' % int(data,16));  
    DataFileReal.close()

def PrintMat4ChirpFullscale():
    aChirp = io.loadmat('chirp_data_32767_fullscale.mat')
    print(aChirp)
    aComp = aChirp['chirp_data_hex']
    DataFileReal = open('DataOutRealFullscale.txt', 'w')
    for data in aComp:
        if(int(data,16) > 32767):
            DataFileReal.write('%d\n' % -(65536 - int(data,16)) );  
        else:
            DataFileReal.write('%d\n' % int(data,16));  
    DataFileReal.close()

def PrintMat4ChirpPD():
    aChirp = io.loadmat('chirp_data_pd.mat')
    print("type aChirp = ",type(aChirp))
    print(aChirp)
    aComp = aChirp['chirp_data']
    print("type aComp  = ",type(aComp))
    DataFileReal = open('DataOutRealPD.txt', 'w')
    for list in aComp:
        for Complex in list:
            DataFileReal.write('%d\n' % Complex.real);  
    DataFileReal.close()

def PrintMat4ChirpPdNew221013():
    aChirp = io.loadmat('chirp_data_pd_new221013.mat')
    print("type aChirp = ",type(aChirp))
    print(aChirp)
    aComp = aChirp['chirp_data']
    print("type aComp  = ",type(aComp))
    DataFileReal = open('DataOutRealPD_new221013.txt', 'w')
    for list in aComp:
        for Complex in list:
            DataFileReal.write('%d\n' % Complex.real);  
    DataFileReal.close()

def PrintMat4ChirpLut():
    aChirp = io.loadmat('CSAR_LUT.mat')
    print(aChirp)
    aComp = aChirp['CSAR_LUT_10']
    DataFileReal = open('DataOutRealLut.txt', 'w')
    for data in aComp:
       DataFileReal.write('%d\n' % int(data[0]));  # numpy.complex128
       DataFileReal.write('%d\n' % int(data[1]));  # numpy.complex128
    DataFileReal.close()

#
#	for Python convert file without LUT range -
#
def ConvMat4Python():
    aAddDic = {}
    for sKey in list(aDic.keys()):
        print('Store Key ' + sKey)
        if   (sKey[5:8] == 'QST'):
            aAddDic[sKey] = aDic[sKey]   #dict[sKey, aDic[sKey]]
        elif (sKey[5:8] == 'LUT'):
            aLUT = aDic[sKey]
            Bit = int(sKey[9:])
            lutsz = 2 ** Bit
            #print('\tLUT 12:%d' % Bit)
            for m in range(0, 32):
                aLUT[m] = aLUT[m][math.floor(lutsz/2):]
            aAddDic[sKey] = aLUT
    print(list(aAddDic.keys()))
    with open('BaqTable.Dic', 'wb') as fw:
        pickle.dump(aAddDic, fw)

#
#	for Verilog readmemh  Print QST from QST orginal(Lut*2, Lut*2-1)
#
def PrintMat4QstVerilogFromQst():
    first = True
    for Bit in [8, 6, 5, 4]:    #   10,
        if (first):
            aQST1st = GetQstFromDic(Bit)
            first = False
        aQST = GetQstFromDic(Bit)
        for m in range(0, 32):
            fmt = "%%%dx" % CeilLog16(aQST1st[m])
            if (m == 31):
                if (Bit == 4):
                    print(fmt % aQST[m])
                else:
                    print(fmt % aQST[m], end=',\n')
            else:
                print(fmt % aQST[m], end=', ')
    print("=" * 70)

#
#	for Verilog readmemh  Print QST from LUT(QST / 2)
#
def PrintMat4QstVerilogFromLut():
    first = True
    for Bit in [8, 6, 5, 4]:    #   10,
        if (first):
            aLUT1st = GetLutFromDic(Bit)
            first = False
        aLUT = GetLutFromDic(Bit)
        lutsz = 2 ** Bit
        for m in range(0, 32):
            fmt = "%%%dx" % CeilLog16(aLUT1st[m][lutsz-1])
            if (m == 31):
                if (Bit == 4):
                    print(fmt % aLUT[m][lutsz-1])
                else:
                    print(fmt % aLUT[m][lutsz-1], end=',\n')
            else:
                print(fmt % aLUT[m][lutsz-1], end=', ')
    print("=" * 70)

#
#	for Verilog readmemh  Print LUT
#
def PrintMat4LutVerilog():
    for Bit in [8, 6, 5, 4]:   #[4]:    #   #10,
        aLUT = GetLutFromDic(Bit)
        lutsz = 2 ** Bit
        for m in range(0, 32):
            for n in range(math.floor(lutsz/2), lutsz):
                fmt = "%%%dx" % CeilLog16(aLUT[31][n])
                if (n == lutsz-1):
                    if (m == 31 and Bit == 4):
                        print(fmt % aLUT[m][n])
                    else:
                        print(fmt % aLUT[m][n], end=',\n')
                else:
                    print(fmt % aLUT[m][n], end=', ')
    print("=" * 70)

#
#	for Python QST and LUT
#
def PrintMat4Python():
    aQST10 = GetQstFromDic(10)
    for Bit in [10, 8, 6, 5, 4]:
        aQST = GetQstFromDic(Bit)
        for m in range(0, 32):
            fmt = "%%%dd" % CeilLog10(aQST10[m])
            if (m == 0):
                print('[', end='')
            if (m == 31):
                print(fmt % aQST[m], end=']\n')
            else:
                print(fmt % aQST[m], end=', ')
    print("=" * 70)
    for Bit in [8, 6, 5, 4]:   #[4]:    #   #10,
        aLUT = GetLutFromDic(Bit)
        lutsz = 2 ** Bit
        for m in range(0, 32):
            for n in range(math.floor(lutsz/2), lutsz):
                fmt = "%%%dd" % CeilLog10(aLUT[31][n])
                if (n == math.floor(lutsz/2)):
                    if (m == 0):
                        print('[', end='')
                    print('[', end='')
                if (n == lutsz-1):
                    if (m == 31):
                        print(fmt % aLUT[m][n], end=']]\n')
                    else:
                        print(fmt % aLUT[m][n], end='],\n')
                else:
                    print(fmt % aLUT[m][n], end=', ')
    print("=" * 70)

def RandomDataGen(Bit):
    random.seed(220404)
    DataFileReal = open('DataInRandomReal.txt', 'w')
    DataFileImage = open('DataInRandomImage.txt', 'w')
    RanVal = 2 ** (Bit-1) - 1
    for i in range(700):
        DataFileReal.write('%d\n' % random.randint(-RanVal, RanVal))
        DataFileImage.write('%d\n' % random.randint(-RanVal, RanVal))
    DataFileReal.close()
    DataFileImage.close()

def	ReadFileToIntList(Name):
	File = open(Name)
	aList = []
	for sBuf in File:
		aList.append(int(sBuf))
	File.close()
	return aList

def	FoundLastZero(aI, aQ):
	LenMin = min(len(aI), len(aQ))
	i = 0
	for i in range(LenMin, 0, -1):
		if (aI[i-1] != 0 or aQ[i-1] != 0):
			break
	return i

def GainDataGen(Bit):
    global BlockSize
    aDataInI = ReadFileToIntList('./tbi_chirp_real_12bit.txt')
    aDataInQ = ReadFileToIntList('./tbi_chirp_imag_12bit.txt')
    print('Total Min-Max')
    MinI = np.min(aDataInI)
    MaxI = np.max(aDataInI)
    MinQ = np.min(aDataInQ)
    MaxQ = np.max(aDataInQ)
    print('\tI: ', MinI, MaxI)
    print('\tQ: ', MinQ, MaxQ)
    MinIT = min(MinI, MinQ)
    MaxQT = max(MaxI, MaxQ)
    MaxT  = max(abs(MinIT), MaxQT)
    print('\tT: ', MinIT, MaxQT, MaxT)

    AvailableLen = FoundLastZero(aDataInI, aDataInI)
    LastBlock	=	math.ceil(AvailableLen/BlockSize)
    random.seed(220405)

    DataFileReal = open('DataInGainReal.txt', 'w')
    DataFileImage = open('DataInGainImage.txt', 'w')
    for BlockNo in range(LastBlock):	#
        Gain = 2 ** ((random.random() * ((Bit-1)-4)) + 4)
        if Gain >= (2**(Bit-1)):
            Gain = (2**(Bit-1)) - 1
        print('BlockNo: ', BlockNo, 'Gain: ', math.ceil(Gain))
        BlockGain = math.floor(Gain * ((2**(Bit-1)) - 1) / MaxT)
        if (BlockNo < LastBlock-1) or (AvailableLen%BlockSize == 0):
            for i in range(BlockSize):
                DataFileReal.write('%d\n' % ((aDataInI[BlockNo*BlockSize + i] * BlockGain) >> (Bit-1)))
                DataFileImage.write('%d\n' % ((aDataInQ[BlockNo*BlockSize + i] * BlockGain) >> (Bit-1)))
        else:
            for i in range(AvailableLen % BlockSize):
                DataFileReal.write('%d\n' % ((aDataInI[BlockNo*BlockSize + i] * BlockGain) >> (Bit-1)))
                DataFileImage.write('%d\n' % ((aDataInQ[BlockNo*BlockSize + i] * BlockGain) >> (Bit-1)))
    DataFileReal.close()
    DataFileImage.close()

#PrintMat4Python()
#PrintMat4Chirp()
#PrintMat4Chirp1g()
#PrintMat4Chirp1g5()
#PrintMat4ChirpHex()
#PrintMat4ChirpFullscale()
#PrintMat4ChirpPD()
#PrintMat4ChirpPdNew221013()
#PrintMat4ChirpLut()
PrintMat4QstVerilogFromQst()
#PrintMat4QstVerilogFromLut()
#PrintMat4LutVerilog()
#ConvMat4Python()
#PrintTest()
#RandomDataGen(12)
#GainDataGen(12)