import math
import pickle
from matplotlib import pyplot as plt
import numpy as np

#
#   ==============================================================================
#	Load Dictionary from ConvMat4Python() of ReadMatFile.py
#		Bit 8	12:8
#		Bit	6	12:6
#		Bit	5	12:5
#		Bit	4	12:4	:other
with open('BaqTable.Dic', 'rb') as fr:
	aBaqDic = pickle.load(fr)

#
#   ==============================================================================
#	Get<Qst,Lut>FromDic(Bit)
#		Bit 10	12:10
#		Bit 8	12:8
#		Bit	6	12:6
#		Bit	5	12:5
#		Bit	4	12:4	:other
def GetQstFromDic(Bit):
    sName = 'CSAR_QST_%d' % Bit
    return aBaqDic[sName]

def GetLutFromDic(Bit):
    sName = 'CSAR_LUT_%d' % Bit
    return aBaqDic[sName]

NumLUT = 32
LastLUT = NumLUT-1
BlockSize = 128
#
#	for Verilog readmemh  Print QST 1/2	from LUT
#
def CheckQstWithLut():
	for Bit in [8, 6, 5, 4]:    #   10,
		aQST = GetQstFromDic(Bit)
		aLUT = GetLutFromDic(Bit)
		lutsz = 2 ** (Bit-1)
		print('Check Baq 12:%d' % Bit)
		for m in range(0, 32):
			if (aQST[m] > aLUT[m][lutsz-1] * 2 + 1) or (aQST[m] < aLUT[m][lutsz-1] * 2):
				print('m:%d QST:%d LUT:%d Diff:%d' % (m, aQST[m], aLUT[m][lutsz-1], aQST[m] - aLUT[m][lutsz-1] * 2))
	print("=" * 70)

def	ReadFileToIntList(Name):
	File = open(Name)
	aList = []
	for sBuf in File:
		aList.append(int(sBuf))
	File.close()
	return aList

def	MakeDiffJpg():
	global Bit, aLUT, lutsz

	for Bit in [8, 6, 5, 4]:
		aLUT = GetLutFromDic(Bit)
		lutsz = 2 ** (Bit-1)

		aPlus = np.arange(0, 32)
		aMinus = np.arange(0, 32)
		for t in range(0, 32):
			aArray =  aLUT[t]
			lutlast = lutsz - 1
			last = aArray[lutlast]
			x  = np.arange(0, last+1)
			y1 = np.arange(0, last+1)
			y2 = np.arange(0, last+1)
			yd = np.arange(0, last+1)
			for s in range(0, last+1):
				if (s == 0):
					y1[s] = 0;
				if (s == last):
					y1[s] = lutlast
				else:
					IdxBase = s * lutsz / last
					y1[s] = IdxBase

				if (s == 0):
					n = 0;
				elif (s == last):
					n = lutlast
				else:
					for n in range(0, lutsz):
						if (s <= aArray[n]):
							break
				y2[s] = n
			yd = y2 - y1

			aMinus[t] = last
			for s in range(0, last+1):
				if (yd[s] > 0):
					aPlus[t] = s
				elif (yd[s] < 0):
					if (aMinus[t] == last):
						aMinus[t] = s

			plt.subplot(2,1,1)
			plt.plot(x, y1, 'r', label='base')
			plt.plot(x, y2, 'g', label='n')
			plt.legend(loc='upper left')
			plt.title(f'12:{Bit} BAQ LUT[{t}]')
			plt.subplot(2,1,2)
			plt.plot(x, yd, 'c', label='diff')
			plt.legend(loc='upper center')
			plt.plot(aPlus[t], 0.5,'^m')
			if (aMinus[t] != last):
				plt.plot(aMinus[t], -0.5,'vm')
			Filename = f'BAQ_{Bit}_LUT{t}.jpg'
			plt.savefig(Filename)
			plt.close()

def GetQstWithLut(Bit, m):
	aLUT = GetLutFromDic(Bit)
	lutsz = 2 ** (Bit-1)
	return aLUT[m][lutsz-1]

def SearchQstWithLut(max, aLUT, lutsz, Bit):
	for m in range(32):
		if (max <= aLUT[m][lutsz-1]):
			break
	return m, aLUT[m][lutsz-1]

def SearchLut(x, aSubLUT, lutsz):
	for n in range(lutsz):
		if (x <= aSubLUT[n]):
			break
	n_1 = 0
	if (n < 1):
		n_1 = 0
	else:
		n_1 = n - 1
	#print(x, n_1, ':', aSubLUT[n_1], n, ':', aSubLUT[n])
	return n

def SignAbs(aBlock, aSign, aAbs):
	global BlockSize
	for i in range(BlockSize):
		if (aBlock[i] < 0):
			aSign[i] = -1
		else:
			aSign[i] = 1
		if (aBlock[i] < -2048):
			aAbs[i] = 2047
		else:
			aAbs[i] = aBlock[i] * aSign[i]

#
#   Bit: 10, 8, 6, 5, 4
#	aI, aQ : List of size BlockSize
#
def	Baq(Bit, aI, aQ, BaqI, BaqQ):
	global BlockSize
	aSignI = np.arange(BlockSize)
	aAbsI  = np.arange(BlockSize)
	aSignQ = np.arange(BlockSize)
	aAbsQ  = np.arange(BlockSize)
	SignAbs(aI, aSignI, aAbsI)
	SignAbs(aQ, aSignQ, aAbsQ)
	Imax = np.max(aAbsI)
	Qmax = np.max(aAbsQ)
	Tmax = max(Imax, Qmax)
	aLUT = GetLutFromDic(Bit)
	lutsz = 2 ** (Bit-1)
	M, C = SearchQstWithLut(Tmax, aLUT, lutsz, Bit)
	print ('Max ', Imax, Qmax, Tmax, M, C)
	for i in range(BlockSize):
		nI = SearchLut(aAbsI[i], aLUT[M], lutsz)
		BaqI[i] = aSignI[i] * nI
		nQ = SearchLut(aAbsQ[i], aLUT[M], lutsz)
		BaqQ[i] = aSignQ[i] * nQ
	#	print(i, aI[i], nI, BaqI[i], end=' | ')
	#	print(aQ[i], nQ, BaqQ[i])

def CeilLog10(x):
	l = 0
	if (x == 0):
		l = 1
	else:
		l = math.ceil(math.log10(x))
	return l
def CeilLog16(x):
	l = 0
	if (x == 0):
		l = 1
	else:
		l = math.ceil(math.log2(x)/4)
	return l

def	LoadChirpFile():
	ChirpR = ReadFileToIntList('./tbi_chirp_real_12bit.txt')
	ChirpI = ReadFileToIntList('./tbi_chirp_imag_12bit.txt')
	plt.subplot(2,1,1)
	x  = np.arange(0, len(ChirpI))
	plt.plot(x, ChirpR)
	plt.legend(loc='upper left')
	plt.title('real')
	plt.subplot(2,1,2)
	plt.plot(x, ChirpI)
	plt.legend(loc='upper left')
	plt.title('image')
	plt.show()

def	FoundLastZero(aI, aQ):
	LenMin = min(len(aI), len(aQ))
	i = 0
	for i in range(LenMin, 0, -1):
		if (aI[i-1] != 0 or aQ[i-1] != 0):
			break
	return i

def MakeData():
	aDataInI = ReadFileToIntList('./tbi_chirp_real_12bit.txt')
	aDataInQ = ReadFileToIntList('./tbi_chirp_imag_12bit.txt')
	#aDataInI = ReadFileToIntList('./DataInRandomReal.txt')
	#aDataInQ = ReadFileToIntList('./DataInRandomImage.txt')
	#aDataInI = ReadFileToIntList('./DataInGainReal.txt')
	#aDataInQ = ReadFileToIntList('./DataInGainImage.txt')
	print('Total Min-Max')
	print('\tI: ', np.min(aDataInI), np.max(aDataInI))
	print('\tQ: ', np.min(aDataInQ), np.max(aDataInQ))
	print('#' * 80)
	AvailableLen = FoundLastZero(aDataInI, aDataInI)
	LastBlock	=	math.ceil(AvailableLen/BlockSize)
	DataI = np.arange(BlockSize)
	DataQ = np.arange(BlockSize)
	BaqI = np.arange(BlockSize)
	BaqQ = np.arange(BlockSize)
	for Bit in [8, 4]:	#	[10, 8, 6, 5, 4]:	#
		print('BAQ Ratio 12:', Bit)
	#	Name = f'OutPythonReal{Bit}.txt'
	#	Name = f'OutPythonRandomReal{Bit}.txt'
		Name = f'OutPythonGainReal{Bit}.txt'
		OutFileReal = open(Name, 'w')
		OutFileReal.write('BAQ Ratio 12: %d\n' % Bit)
	#	Name = f'OutPythonImage{Bit}.txt'
	#	Name = f'OutPythonRandomImage{Bit}.txt'
		Name = f'OutPythonGainImage{Bit}.txt'
		OutFileImage = open(Name, 'w')
		OutFileImage.write('BAQ Ratio 12: %d\n' % Bit)
		for BlockNo in range(LastBlock):	#
		#	Gain = GetQstWithLut(Bit, (BlockNo * 3) & 31)
		#	print('BlockNo: ', BlockNo, 'Gain: ', Gain)
		#	Gain = math.floor((Gain-((BlockNo*5) & 7)) * 2047 / 1433)
			if (BlockNo < LastBlock-1) or (AvailableLen%BlockSize == 0):
				for i in range(BlockSize):
					DataI[i] = (aDataInI[BlockNo*BlockSize + i])# * Gain) >> 11
					DataQ[i] = (aDataInQ[BlockNo*BlockSize + i])# * Gain) >> 11
			else:
				for i in range(AvailableLen % BlockSize):
					DataI[i] = (aDataInI[BlockNo*BlockSize + i])# * Gain) >> 11
					DataQ[i] = (aDataInQ[BlockNo*BlockSize + i])# * Gain) >> 11
				for i in range(AvailableLen % BlockSize, BlockSize):	# Fill Zero
					DataI[i] = 0
					DataQ[i] = 0
			Baq(Bit, DataI, DataQ, BaqI, BaqQ)
	#		print(DataI)
			for i in range(BlockSize):
				if (i != 0 and i % 16 == 15):
					OutFileReal.write('%5d,\n' % BaqI[i])
				else:
					OutFileReal.write('%5d, ' % BaqI[i])
			for i in range(BlockSize):
				if (i != 0 and i % 16 == 15):
					OutFileImage.write('%5d,\n' % BaqQ[i])
				else:
					OutFileImage.write('%5d, ' % BaqQ[i])
		OutFileReal.close()
		OutFileImage.close()

def MakeDataOrg():
	aDataInI = ReadFileToIntList('./tbi_chirp_real_12bit.txt')
	aDataInQ = ReadFileToIntList('./tbi_chirp_imag_12bit.txt')
	Name = f'OutPythonReal.txt'
	OutFileReal = open(Name, 'w')
	Name = f'OutPythonImage.txt'
	OutFileImage = open(Name, 'w')
	for i in range(len(aDataInI)):
		Ival = aDataInI[i] * 4
		OutFileReal.write('%d\n' % Ival)
	for i in range(len(aDataInQ)):
		Qval = aDataInQ[i] * 4
		OutFileImage.write('%d\n' % Qval)
	OutFileReal.close()
	OutFileImage.close()


#CheckQstWithLut()
#MakeDiffJpg()
#LoadChirpFile()
#MakeData()
#MakeDataOrg()